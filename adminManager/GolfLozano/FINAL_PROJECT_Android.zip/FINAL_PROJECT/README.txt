El unico requisito es crear un data source que se llame "jdbc/appsNube" .

O si configuras uno extra puedes modificar el com.iteso.appsnube.db.DBUtil con el nombre,
los.java estan dentro del WAR.

Hay tres usuarios. El UI es completamente Dinamico esta vez.